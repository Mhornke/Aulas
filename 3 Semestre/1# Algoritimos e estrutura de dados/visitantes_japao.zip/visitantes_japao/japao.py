import csv
from itertools import groupby
from operator import itemgetter

visitantes = []

with open("Number of foreign visitors to Japan by month_ .csv") as arq:
    linhas = csv.DictReader(arq)
    for linha in linhas:
        visitantes.append(linha)


def titulo(texto):
    print()
    print(texto)
    print("="*40)

def top20():
    # Nº País NºVisitantes
    pass

def total_ano():
    # Ano NºVisitantes
    pass

def top10_22_23():
    # Listar Pais e NºVisitantes dos 10+ de 2022
    # Listar Pais e NºVisitantes dos 10+ de 2023
    # Mostrar a união dos 10+ de cada ano
    # Mostrar a interseção dos 10+ de cada ano
    # Mostrar os que só apareceram em 2022
    # Mostrar os que só apareceram em 2023
    pass
    

# ------------------------------------------------------ Programa Principal
while True:
    titulo("Visitantes Estrangeiros no Japão: 2017 à 2023")
    print("1. Top 20 - Países com maior número de visitantes")
    print("2. Total de Visitantes por ano")
    print("3. Top 10: Visitantes 2022 e 2023")
    print("4. Finalizar")
    opcao = int(input("Opção: "))
    if opcao == 1:
        top20()
    elif opcao == 2:
        total_ano()
    elif opcao == 3:
        top10_22_23()
    else:
        break
