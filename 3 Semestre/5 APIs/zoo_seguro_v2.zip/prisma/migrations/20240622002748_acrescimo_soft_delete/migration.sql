-- AlterTable
ALTER TABLE `animais` ADD COLUMN `deleted` BOOLEAN NOT NULL DEFAULT false;
